document.getElementById("offerButton").addEventListener("click", function () {
	document.getElementById("offerMessage").style.display = "block";
	console.log('botón pulsado');
});
